package com.example.pandemicontrol

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
